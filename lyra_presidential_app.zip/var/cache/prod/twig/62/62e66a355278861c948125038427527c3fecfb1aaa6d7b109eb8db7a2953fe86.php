<?php

/* AppBundle:Presidencial:agregar-acta-presidencial.html.twig */
class __TwigTemplate_4f31e1c5534444072357d70fa628d1ccfbd6515655808caee4d604955f01ff9b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "﻿<!DOCTYPE html>
<html>

<head>
    <meta charset=\"UTF-8\">
    <meta content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\" name=\"viewport\">
    <title>Agregar Acta Presidencial | Lyra Electoral App</title>
    <!-- Favicon-->
    <link rel=\"icon\" href=\"../../favicon.ico\" type=\"image/x-icon\">

    <!-- Google Fonts -->
    <link href=\"https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext\" rel=\"stylesheet\" type=\"text/css\">
    <link href=\"https://fonts.googleapis.com/icon?family=Material+Icons\" rel=\"stylesheet\" type=\"text/css\">

    <!-- Bootstrap Core Css -->
    <link href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendors/bootstrap/css/bootstrap.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

        <!-- Bootstrap Select Css -->
  <link href=\"https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css\" rel=\"stylesheet\" />

    <!-- Waves Effect Css -->
    <link href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendors/node-waves/waves.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />

    <!-- Animation Css -->
    <link href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendors/animate-css/animate.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />

    <!-- Sweet Alert Css -->
    <link href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendors/sweetalert/sweetalert.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />

    <!-- Custom Css -->
    <link href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendors/css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendors/css/themes/all-themes.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
    <script>
    function validate(evt) {
  var theEvent = evt || window.event;
  var key = theEvent.keyCode || theEvent.which;
  key = String.fromCharCode( key );
  var regex = /[0-9]|\\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}</script>
</head>

<body class=\"theme-red\">
    <!-- Page Loader -->
    <div class=\"page-loader-wrapper\">
        <div class=\"loader\">
            <div class=\"preloader\">
                <div class=\"spinner-layer pl-red\">
                    <div class=\"circle-clipper left\">
                        <div class=\"circle\"></div>
                    </div>
                    <div class=\"circle-clipper right\">
                        <div class=\"circle\"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class=\"overlay\"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
   
    <!-- #END# Search Bar -->
      ";
        // line 72
        $this->loadTemplate("layouts/topbar.html.twig", "AppBundle:Presidencial:agregar-acta-presidencial.html.twig", 72)->display($context);
        // line 73
        echo "    <section>
        ";
        // line 74
        $this->loadTemplate("layouts/sidebar.html.twig", "AppBundle:Presidencial:agregar-acta-presidencial.html.twig", 74)->display($context);
        // line 75
        echo "    </section>

    <section class=\"content\">
        <div class=\"container-fluid\">
           

            <!-- Vertical Layout -->
            <div class=\"row clearfix\">
                <div class=\"col-lg-12 col-md-12 col-sm-12 col-xs-12\">
                    <div class=\"card\">
                        <div class=\"header\">
                            <h2>
                                AGREGAR RESULTADOS ACTA PRESIDENCIAL
                            </h2>
                          
                        </div>
                        <div class=\"body\">
                            ";
        // line 92
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["concejo"]) ? $context["concejo"] : null), 'form_start');
        echo "
                            
                            <label for=\"email_address\">CENTRO DE VOTACION:</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 97
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "centrovotacion", array()), 'widget');
        echo "
                                        
                                    </div>
                                </div>
                                        
                                          <label for=\"email_address\">NUMERO JRV</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\">
                                        ";
        // line 105
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "jrv", array()), 'widget');
        echo "
                                        
                                    </div>
                                </div>
                                        
                                           </br>    
                                <label for=\"email_address\">VOTOS SOBRANTES</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 114
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "sobrantes", array()), 'widget', array("type" => "number"));
        echo "
                                        
                                    </div>
                                </div>     
                                        
                                         </br>    
                                <label for=\"email_address\">INUTILIZADAS</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 123
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "inutilizadas", array()), 'widget', array("type" => "number"));
        echo "
                                        
                                    </div>
                                </div> 
                                        
                                        </br>
                                        
                              </br>
                               <label for=\"email_address\">VOTOS FMLN</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 134
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "fmln", array()), 'widget', array("type" => "number"));
        echo "
                                        
                                    </div>
                                </div>
                                        
                                        
                                        </br>
                               <label for=\"email_address\">VOTOS GANA</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 144
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "gana", array()), 'widget', array("type" => "number"));
        echo "
                                        
                                    </div>
                                </div>    
                                        
                                        
                                         </br>
                               <label for=\"email_address\">VOTOS VAMOS</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 154
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "vamos", array()), 'widget', array("type" => "number"));
        echo "
                                        
                                    </div>
                                </div> 
                                        
                                        </br>
                               <label for=\"email_address\">VOTOS ARENA</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 163
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "arena", array()), 'widget', array("type" => "number"));
        echo "
                                        
                                    </div>
                                </div>
                                        
                                        
                                        
                                        
                                
                                      </br>
                               <label for=\"email_address\">VOTOS PCN</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 176
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "pcn", array()), 'widget', array("type" => "number"));
        echo "
                                        
                                    </div>
                                </div> 
                                        
                                         </br>
                               <label for=\"email_address\">VOTOS PDC</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 185
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "pdc", array()), 'widget', array("type" => "number"));
        echo "
                                        
                                    </div>
                                </div> 
                                        
                                        
                                </br>
                               <label for=\"email_address\">VOTOS DS</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 195
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "ds", array()), 'widget', array("type" => "number"));
        echo "
                                        
                                    </div>
                                </div>
                                        
                                        
                                        </br>
                               <label for=\"email_address\">ARENA-PCN-PDC-DS</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 205
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "coalicion", array()), 'widget');
        echo "
                                        
                                    </div>
                                </div>  
                                        
                              
                                        
                                        
                               
                                    </br>    
                                <label for=\"email_address\">VOTOS IMPUGNADOS</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 218
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "impugnados", array()), 'widget', array("type" => "number"));
        echo "
                                        
                                    </div>
                                </div> 
                                        
                                        
                                </br>    
                                <label for=\"email_address\">VOTOS NULOS</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 228
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "nulo", array()), 'widget', array("type" => "number"));
        echo "
                                        
                                    </div>
                                </div> 
                                        
                             
                                     </br>
                               <label for=\"email_address\">ABSTENCIONES</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 238
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "abstenciones", array()), 'widget', array("type" => "number"));
        echo "
                                        
                                    </div>
                                </div> 
                                        
                                        
                                         </br>
                               <label for=\"email_address\">ESCRUTADOS</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 248
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "escrutados", array()), 'widget', array("type" => "number"));
        echo "
                                        
                                    </div>
                                </div> 
                                        
                                </br>    
                                <label for=\"email_address\">VOTOS FALTANTES</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 257
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "faltantes", array()), 'widget', array("type" => "number"));
        echo "
                                        
                                    </div>
                                </div>
                                        
                                        
                               
                                        
                                        </br>    
                                <label for=\"email_address\">ENTREGADOS</label>
                                <div class=\"form-group\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 269
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "entregados", array()), 'widget', array("type" => "number"));
        echo "
                                        
                                    </div>
                                </div> 
                                        
                                        
                                        
                                     </br>    
                                
                                <div class=\"form-group\" style=\"display: none;\">
                                    <div class=\"form-line\" onkeypress='validate(event)'>
                                        ";
        // line 280
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "municipioid", array()), 'widget', array("value" => "1"));
        echo "
                                        
                                    </div>
                                </div>   
                                        
                                        
                                
                                        
                                <br>
                                ";
        // line 289
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["concejo"]) ? $context["concejo"] : null), "guardar", array()), 'widget');
        echo "
                               
                            ";
        // line 291
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["concejo"]) ? $context["concejo"] : null), 'form_end');
        echo "
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Vertical Layout -->
  
            
           
          
           
          
        </div>
    </section>

    <!-- Jquery Core Js -->
    <script src=\"";
        // line 307
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendors/jquery/jquery.min.js"), "html", null, true);
        echo "\"></script>

    <!-- Bootstrap Core Js -->
    <script src=\"";
        // line 310
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendors/bootstrap/js/bootstrap.js"), "html", null, true);
        echo "\"></script>

    <!-- Select Plugin Js -->
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js\"></script>


    <!-- Slimscroll Plugin Js -->
    <script src=\"";
        // line 317
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendors/jquery-slimscroll/jquery.slimscroll.js"), "html", null, true);
        echo "\"></script>

    <!-- Waves Effect Plugin Js -->
    <script src=\"";
        // line 320
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendors/node-waves/waves.js"), "html", null, true);
        echo "\"></script>

    <!-- Custom Js -->
    <script src=\"";
        // line 323
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendors/js/admin.js"), "html", null, true);
        echo "\"></script>

    <!-- Demo Js -->
    <script src=\"";
        // line 326
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/vendors/js/demo.js"), "html", null, true);
        echo "\"></script>
    <script>
    \$(document).ready(function() {
    \$('.select4').select2();
});
    </script>
    
    
    
    <script>
        \$('#acta_presidencial_centrovotacion').change(function () {
            var sectorElectoral = \$(this);
            
            // Request the neighborhoods of the selected city.
            \$.ajax({
                url: \"";
        // line 341
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("jrv_sector_electoral");
        echo "\",
                type: \"GET\",
                dataType: \"JSON\",
                data: {
                    sectorid: sectorElectoral.val()
                },
                success: function (juntas) {
                    var jrvSelect = \$(\"#acta_presidencial_jrv\");

                    // Remove current options
                    jrvSelect.html('');
                    
                    // Empty value ...
                    jrvSelect.append('<option value> Seleccione JRV de ' + sectorElectoral.find(\"option:selected\").text() + ' ...</option>');
                    
                    
                    \$.each(juntas, function (key, jrv) {
                        jrvSelect.append('<option value=\"' + jrv.id + '\">' + jrv.name + '</option>');
                    });
                },
                        
                        
                
                error: function (err) {
                    alert(\"An error ocurred while loading data ...\");
                }
            });
        });
    </script> 
</body>

</html>";
    }

    public function getTemplateName()
    {
        return "AppBundle:Presidencial:agregar-acta-presidencial.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  469 => 341,  451 => 326,  445 => 323,  439 => 320,  433 => 317,  423 => 310,  417 => 307,  398 => 291,  393 => 289,  381 => 280,  367 => 269,  352 => 257,  340 => 248,  327 => 238,  314 => 228,  301 => 218,  285 => 205,  272 => 195,  259 => 185,  247 => 176,  231 => 163,  219 => 154,  206 => 144,  193 => 134,  179 => 123,  167 => 114,  155 => 105,  144 => 97,  136 => 92,  117 => 75,  115 => 74,  112 => 73,  110 => 72,  69 => 34,  63 => 31,  57 => 28,  51 => 25,  45 => 22,  36 => 16,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "AppBundle:Presidencial:agregar-acta-presidencial.html.twig", "/home/milocker/presidencial.swsocialweb.com/src/AppBundle/Resources/views/Presidencial/agregar-acta-presidencial.html.twig");
    }
}
